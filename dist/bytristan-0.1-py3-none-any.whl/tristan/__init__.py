from .tristan import tristanprint, enforce_tristan, start_enforcement, rainbow_text, default_comment_ending
