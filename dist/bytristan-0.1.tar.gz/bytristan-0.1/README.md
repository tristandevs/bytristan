# Tristan Module
This module enforces the use of special Tristan comments in Python code.
